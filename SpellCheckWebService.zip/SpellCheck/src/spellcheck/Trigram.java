/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package spellcheck;

/**
 *
 * @author TUNG
 */
public class Trigram {
    short first;
    short second;
    short last;
    int frequency;
}
