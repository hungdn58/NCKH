var images = document.getElementsByTagName('img');
// for (var i = 0, l = images.length; i < l; i++) {
//   images[i].src = 'http://placekitten.com/' + images[i].width + '/' + images[i].height;
// }

// document.body.innerHTML = document.body.innerHTML.replace('Create a Chrome extension to modify a website’s HTML or CSS', 'Ngoc Hung');
var host = "http://localhost:8089/demo/mistake";

// chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
//   if (request.method == "hello"){
	//   	var xhttp = new XMLHttpRequest();
	//  xhttp.onreadystatechange = function() {
	//     if (xhttp.readyState == 4 && xhttp.status == 200) {
	//     	var result = xhttp.responseText;
	//     	// alert(result);
	//       	sendResponse({data: result});
	//     }
	// };
	// xhttp.open("POST", host, false);
	// xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
	// xhttp.send("string=" + window.getSelection().toString());
// 	document.body.innerHTML = document.body.innerHTML.replace('Create a Chrome extension to modify a website’s HTML or CSS', 'Ngoc Hung');
//   	alert("sang day r nhe");

//   }else {
//   	sendResponse({}); // snub them.
//   }
// });

// chrome.browserAction.onClicked.addListener(function(tab) {
//   // No tabs or host permissions needed!
//   console.log('Turning ' + tab.url + ' red!');
//   chrome.tabs.executeScript({
//     code: 'document.body.style.backgroundColor="red"'
//   });
// });

var arr = ["Create a Chrome extension,xin chao <span style='color:red;'>ban </span> Do Ngoc Hung",
			"A technique we use to visualise,A technique we <span style='color:blue;'>use to</span> visualise"];

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    // console.log(sender.tab.url);
    if (request.greeting == "hello"){
      console.log(request.url);
    	// console.log(document.body.innerHTML);

      // $.post(host,
      // {
      //     content: "hom qua cửa hang đã bị cháy"
      // },
      // function(data, status){
      //     console.log("Data: " + data + "\nStatus: " + status);
      // });

      var xhttp = new XMLHttpRequest();
       xhttp.onreadystatechange = function() {
          if (xhttp.readyState == 4 && xhttp.status == 200) {
            var result = xhttp.responseText;
            console.log(JSON.parse(result));
            var arrResult = JSON.parse(result);
            // var arrResult = result.split(",");
            // alert(result);
              // sendResponse({data: result});
              for (var i = arrResult.length - 1; i >= 0; i--) {
                console.log(arrResult[i]);
                var arrMistake = arrResult[i].split("-");
                if (document.body.innerHTML.indexOf(arrMistake[0]) !== -1) {
                  document.body.innerHTML = document.body.innerHTML.replace(arrMistake[0], arrMistake[1]);
                }
              }
              
          }
      };
      xhttp.open("POST", host, false);
      xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
      xhttp.send("content=" + request.url);

     //  var arr = [
     //    "Vietnam and ASEAN-Vietnam <span style='color:red;'>and</span> ASEAN",
     //    "news  Trang chủ-news <span style='color:red;'> Trang</span> chủ",
     //    "nhìn  Thế giới-nhìn <span style='color:red;'> Thế</span> giới",
     //    "giới  Kinh doanh-giới <span style='color:red;'> Kinh</span> doanh",
     //    "doanh  Giải trí-doanh <span style='color:red;'> Giải</span> trí",
     //    "trí  Thể thao-trí <span style='color:red;'> Thể</span> thao",
     //    "thao  Pháp luật-thao <span style='color:red;'> Pháp</span> luật",
     //    "luật  Giáo dục-luật <span style='color:red;'> Giáo</span> dục",
     //    "2016  Sức khỏe-2016 <span style='color:red;'> Sức</span> khỏe",
     //    "khỏe  Gia đình-khỏe <span style='color:red;'> Gia</span> đình",
     //    "đình  Du lịch-đình <span style='color:red;'> Du</span> lịch",
     //    "lịch  Khoa học-lịch <span style='color:red;'> Khoa</span> học",
     //    "học  Số hóa-học <span style='color:red;'> Số</span> hóa",
     //    " Xe  Cộng đồng- Xe <span style='color:red;'> Cộng</span> đồng",
     //    "đồng  Tâm sự-đồng <span style='color:red;'> Tâm</span> sự",
     //    " Cười  Rao vặt- Cười <span style='color:red;'> Rao</span> vặt",
     //    "qua  Liên hệ-qua <span style='color:red;'> Liên</span> hệ",
     //    "soạn  Thông tin-soạn <span style='color:red;'> Thông</span> tin",
     //    "Kinh doanh  Vĩ-Kinh <span style='color:red;'>doanh </span> Vĩ",
     //    "Vĩ mô  Kinh-Vĩ <span style='color:red;'>mô </span> Kinh",
     //    "Kinh doanh  Vĩ-Kinh <span style='color:red;'>doanh </span> Vĩ",
     //    "Vĩ mô   -Vĩ <span style='color:red;'>mô </span>  ",
     //    "trương khoán chi-trương <span style='color:red;'>khoán</span> chi",
     //    "được khoán chi-được <span style='color:red;'>khoán</span> chi",
     //    "chỉ khoán chi-chỉ <span style='color:red;'>khoán</span> chi",
     //    "vì cá chết-vì <span style='color:red;'>cá</span> chết",
     //    "chủ  Đặt VnExpress-chủ <span style='color:red;'> Đặt</span> VnExpress",
     //    "chủ  Đặt VnExpress-chủ <span style='color:red;'> Đặt</span> VnExpress",
     //    "chủ  Về đầu-chủ <span style='color:red;'> Về</span> đầu"
     //  ]

    	// for (var i = arr.length - 1; i >= 0; i--) {
    	// 	var string = arr[i].split("-");
    	// 	if (document.body.innerHTML.indexOf(string[0]) !== -1) {
     //      // console.log(string[1]);
    	// 		document.body.innerHTML = document.body.innerHTML.replace(string[0], string[1]);
    	// 	}
    	// }
		// document.body.innerHTML = "Xin chao <span style='color:red;'>ban </span> Do Ngoc Hung";
      	sendResponse({farewell: "goodbye"});
    }
  });