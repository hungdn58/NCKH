$(function(){
  $('#checkbox').click(function(){checkSpelling();});
});

var tabUrl;

function checkSpelling() {
	var checkbox = document.getElementById("checkbox");
	var isCheck = checkbox.checked;
	var url;

	if (isCheck == true) {
		alert("check");
		// chrome.tabs.query({active:true, windowId: chrome.windows.WINDOW_ID_CURRENT}, 
		//   function(tab) {
		//     chrome.tabs.sendMessage(tab[0].id, {method: "check"}, 
		//     function(response){
		//       alert("success");
		//     });
		//   });

		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		  chrome.tabs.sendMessage(tabs[0].id, {greeting: "hello", url: tabUrl}, function(response) {
		  	// console.log(tabs[0].url);
		    console.log(response.farewell);
		    // alert(response.farewell);
		  });
		});
	}


}

chrome.tabs.getSelected(null, function(tab) {
    var tabId = tab.id;
    tabUrl = tab.url;

    console.log(tabUrl);
});
