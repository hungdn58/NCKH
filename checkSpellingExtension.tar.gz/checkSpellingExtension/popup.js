$(function(){
  $('#checkbox').click(function(){checkSpelling();});
});


function checkSpelling() {
	var checkbox = document.getElementById("checkbox");
	var isCheck = checkbox.checked;

	if (isCheck == true) {
		alert("check");
		// chrome.tabs.query({active:true, windowId: chrome.windows.WINDOW_ID_CURRENT}, 
		//   function(tab) {
		//     chrome.tabs.sendMessage(tab[0].id, {method: "check"}, 
		//     function(response){
		//       alert("success");
		//     });
		//   });
		chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
		  chrome.tabs.sendMessage(tabs[0].id, {greeting: "hello"}, function(response) {
		    console.log(response.farewell);
		    alert(response.farewell);
		  });
		});
	}


}
