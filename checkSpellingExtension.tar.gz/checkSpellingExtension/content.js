var images = document.getElementsByTagName('img');
for (var i = 0, l = images.length; i < l; i++) {
  images[i].src = 'http://placekitten.com/' + images[i].width + '/' + images[i].height;
}

// document.body.innerHTML = document.body.innerHTML.replace('Create a Chrome extension to modify a website’s HTML or CSS', 'Ngoc Hung');
var host = "http://localhost:8080/SpellingCheckWebService/webresources/service/paragraph/check";

// chrome.extension.onMessage.addListener(function(request, sender, sendResponse) {
//   if (request.method == "hello"){
// 	 //  	var xhttp = new XMLHttpRequest();
// 	//  xhttp.onreadystatechange = function() {
// 	//     if (xhttp.readyState == 4 && xhttp.status == 200) {
// 	//     	var result = xhttp.responseText;
// 	//     	// alert(result);
// 	//       	sendResponse({data: result});
// 	//     }
// 	// };
// 	// xhttp.open("POST", host, false);
// 	// xhttp.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
// 	// xhttp.send("string=" + window.getSelection().toString());
// 	document.body.innerHTML = document.body.innerHTML.replace('Create a Chrome extension to modify a website’s HTML or CSS', 'Ngoc Hung');
//   	alert("sang day r nhe");

//   }else {
//   	sendResponse({}); // snub them.
//   }
// });

var arr = ["Create a Chrome extension,xin chao <span style='color:red;'>ban </span> Do Ngoc Hung",
			"A technique we use to visualise,A technique we <span style='color:blue;'>use to</span> visualise"];

chrome.runtime.onMessage.addListener(
  function(request, sender, sendResponse) {
    alert(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");
    if (request.greeting == "hello"){
    	console.log(document.body.innerHTML);
    	for (var i = arr.length - 1; i >= 0; i--) {
    		var string = arr[i].split(",");
    		if (document.body.innerHTML.indexOf(string[0]) !== -1) {
    			document.body.innerHTML = document.body.innerHTML.replace(string[0], string[1]);
    		}
    	}
		// document.body.innerHTML = "Xin chao <span style='color:red;'>ban </span> Do Ngoc Hung";
      	sendResponse({farewell: "goodbye"});
    }
  });